/* tslint:disable */
require("./NewListCreationWp.module.css");
const styles = {
  newListCreationWp: 'newListCreationWp_6274c793',
  teams: 'teams_6274c793',
  welcome: 'welcome_6274c793',
  welcomeImage: 'welcomeImage_6274c793',
  links: 'links_6274c793'
};

export default styles;
/* tslint:enable */