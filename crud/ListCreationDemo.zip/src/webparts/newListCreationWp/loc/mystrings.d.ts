declare interface INewListCreationWpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
}

declare module 'NewListCreationWpWebPartStrings' {
  const strings: INewListCreationWpWebPartStrings;
  export = strings;
}
