declare const styles: {
    newListCreationWp: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=NewListCreationWp.module.scss.d.ts.map