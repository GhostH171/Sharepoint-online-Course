import * as React from 'react';
import { INewListCreationWpProps } from './INewListCreationWpProps';
export default class NewListCreationWp extends React.Component<INewListCreationWpProps, {}> {
    constructor(props: INewListCreationWpProps);
    render(): React.ReactElement<INewListCreationWpProps>;
    CreateNewList: () => void;
}
//# sourceMappingURL=NewListCreationWp.d.ts.map